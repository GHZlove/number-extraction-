const {chromium}=require('playwright');
const fs=require('node:fs/promises');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const root=path.resolve(__dirname,'..');
const names=['02-growth','03-weapons','04-extraction','05-shelter','06-bosses','07-maps','08-playtest'];
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1086,height:1448},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:8016/source/carousel.html');
 await page.evaluate(async()=>{await document.fonts.ready;await Promise.all([...document.images].map(image=>image.decode()));});
 const layout=await page.locator('.slide').evaluateAll(slides=>slides.map(slide=>{
  const box=slide.getBoundingClientRect(),footer=slide.querySelector('.footer').getBoundingClientRect();
  const items=[...slide.children].filter(el=>!el.classList.contains('footer')).map(el=>({tag:el.tagName,className:el.className,bottom:el.getBoundingClientRect().bottom-box.top}));
  return{id:slide.id,width:box.width,height:box.height,footerTop:footer.top-box.top,contentBottom:Math.max(...items.map(x=>x.bottom)),horizontalOverflow:[...slide.querySelectorAll('*')].filter(el=>{const r=el.getBoundingClientRect();return r.width&&r.right>box.right+1||r.left<box.left-1;}).map(el=>el.tagName+'.'+el.className)};
 }));
 for(const item of layout){if(item.contentBottom>item.footerTop-8||item.horizontalOverflow.length||item.width!==1086||item.height!==1448)throw Error('Poster content overflow: '+JSON.stringify(item));}
 for(let i=0;i<names.length;i++)await page.locator('#slide'+String(i+2).padStart(2,'0')).screenshot({path:path.join(root,'images',names[i]+'.png')});
 await fs.writeFile(path.join(root,'source/layout-checks.json'),JSON.stringify({browserErrors:errors,slides:layout},null,2)+'\n');
 if(errors.length)throw Error(errors.join('\n'));
 const all=['01-cover',...names],labels=['封面插画','数字成长','武器战斗','撤离决策','庇护所仓库','首领挑战','地图变化','试玩邀请'];
 const preview=`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>数字进化 · 抖音图文预览</title><style>*{box-sizing:border-box}body{background:#fff8ed;margin:0;padding:46px;font-family:'Noto Sans CJK SC','Microsoft YaHei',sans-serif;color:#0a1532}h1{font-size:36px;margin:0 0 13px}p{font-size:18px;line-height:1.8;margin:0 0 30px}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:25px}a{background:white;border:2px solid #14203a;border-radius:14px;overflow:hidden;text-decoration:none;color:inherit;box-shadow:5px 5px #16223a}img{display:block;width:100%;height:auto}b{display:block;font-size:18px;padding:14px 18px}.note{margin:32px 0 0;padding:20px;background:#dbf7ee;border-radius:13px}@media(max-width:1000px){body{padding:20px}.grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}h1{font-size:26px}}@media(max-width:450px){.grid{grid-template-columns:1fr}}</style><h1>数字进化｜抖音首篇图文</h1><p>按01→08上传 · 3:4竖图 · Windows电脑试玩版<br>01为封面插画；02—08使用当前游戏实机演示或地图示意。点击可查看原图。</p><div class="grid">${all.map((name,i)=>`<a href="images/${name}.png" target="_blank"><img src="images/${name}.png" alt="${labels[i]}"><b>${String(i+1).padStart(2,'0')} · ${labels[i]}</b></a>`).join('')}</div><p class="note">上传images文件夹内的8张PNG；本页总览不作为轮播上传。标题、正文、话题和回复模板见「发布文案.txt」。素材已制作，尚未代发。</p></html>`;
 await fs.writeFile(path.join(root,'预览.html'),preview);
 await page.setViewportSize({width:1600,height:1200});
 await page.goto('http://127.0.0.1:8016/'+encodeURIComponent('预览.html'));
 await page.evaluate(async()=>{await document.fonts.ready;await Promise.all([...document.images].map(image=>image.decode()));});
 await page.screenshot({path:path.join(root,'预览总览.png'),fullPage:true});
 await browser.close();console.log('Rendered seven typeset cards with exact source screenshots; all layout checks pass.');
})().catch(e=>{console.error(e);process.exit(1);});
