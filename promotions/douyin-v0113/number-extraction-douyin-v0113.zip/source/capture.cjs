const {chromium}=require('playwright');
const fs=require('node:fs/promises');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/src/main.js',async route=>{
  const response=await route.fetch();
  await route.fulfill({response,body:(await response.text())+'\nwindow.__promo={get raid(){return raid},get renderer(){return renderer},get ui(){return ui},get save(){return save},freeze(){paused=true;input.clear()},resume(){paused=false},start};\n'});
 });
 await page.goto('http://127.0.0.1:8015/');
 await page.waitForSelector('[data-action="start"]');
 await page.evaluate(async()=>{
  const {defaultSave}=await import('./src/storage.js'),{makeEquipment,decorateWeapon}=await import('./src/equipment.js');
  const save=defaultSave();save.credits=2400;save.materials={alloy:84,core:6};
  save.shelter={warehouse:2,storage:2,supply:2,workshop:4,recycler:1};
  save.selectedDifficulty='standard';save.selectedMap='tangram';save.selectedBoss='storm';save.selectedWeapon='rifle';
  save.forged.rifle={level:3,rarity:'green',enchant:'lightning'};
  save.warehouse.items=[
   decorateWeapon(makeEquipment('weapon','plasma','purple','vault-1'),'frost',3),
   decorateWeapon(makeEquipment('weapon','battleaxe','blue','vault-2'),'bleed',2),
   decorateWeapon(makeEquipment('weapon','sniper','green','vault-3'),'critical',2),
   makeEquipment('armor','armor','blue','vault-4'),makeEquipment('laser','laser','white','vault-5')
  ];save.warehouse.nextId=6;
  localStorage.setItem('number-extraction-v11',JSON.stringify(save));
 });
 await page.reload();await page.waitForSelector('[data-action="start"]');await page.evaluate(()=>document.fonts.ready);
 await page.screenshot({path:path.join(root,'assets/shelter.png')});
 await page.locator('[data-action="shelterTab"][data-key="vault"]').click();
 await page.locator('.warehouse-panel').screenshot({path:path.join(root,'assets/warehouse.png')});
 await page.locator('[data-action="shelterTab"][data-key="forge"]').click();
 await page.locator('.forge-panel').screenshot({path:path.join(root,'assets/forge.png')});
 await page.locator('[data-action="shelterTab"][data-key="bosses"]').click();
 await page.locator('.boss-codex').screenshot({path:path.join(root,'assets/boss-codex.png')});
 await page.locator('[data-action="shelterTab"][data-key="deploy"]').first().click();
 await page.locator('[data-action="start"]').click();
 await page.keyboard.down('KeyD');await page.waitForTimeout(1600);await page.keyboard.up('KeyD');
 await page.evaluate(()=>{window.__promo.freeze();document.getElementById('message').style.visibility='hidden';window.__promo.ui.update(window.__promo.raid,window.__promo.save,true,false);});
 await page.screenshot({path:path.join(root,'assets/growth.png')});
 const provenance=await page.evaluate(()=>({seed:window.__promo.raid.world.seed,version:'0.11.3',actualGameplayModules:true,profile:'isolated demonstration save, not player telemetry',staging:'Progress and mid-run positions are staged to show implemented systems. No production source or personal save is changed.'}));
 await page.evaluate(async()=>{
  const r=window.__promo.raid,{isFree}=await import('./src/math.js'),{makeEquipment}=await import('./src/equipment.js');
  r.player.value=64;r.player.armor=makeEquipment('armor','armor','blue','demo-armor');r.player.laser=makeEquipment('laser');
  const site=r.world.sites.find(s=>Math.hypot(s.x-r.player.x,s.y-r.player.y)>1800)||r.world.sites[0];
  for(let d=200;d<550;d+=50){let found=false;for(let i=0;i<20;i++){const a=i*Math.PI/10,x=site.x+Math.cos(a)*d,y=site.y+Math.sin(a)*d;if(isFree(x,y,r.player.radius,r.world.obstacles,r.world.bounds)){Object.assign(r.player,{x,y});found=true;break;}}if(found)break;}
  const target=r.world.enemies.filter(e=>!e.dead&&!e.boss).sort((a,b)=>Math.hypot(a.x-r.player.x,a.y-r.player.y)-Math.hypot(b.x-r.player.x,b.y-r.player.y))[0];
  for(let i=0;i<36;i++)r.update(1/60,{attack:i%2===0,aimX:target.x,aimY:target.y});
  window.__promo.renderer.camera={...r.player};window.__promo.renderer.draw(r,performance.now()/1000,1);window.__promo.ui.update(r,window.__promo.save,true,false);
 });
 await page.waitForTimeout(100);await page.screenshot({path:path.join(root,'assets/combat.png')});
 await page.locator('#loadout-button').click();await page.waitForTimeout(100);
 await page.locator('#dialog').screenshot({path:path.join(root,'assets/inventory.png')});
 await page.locator('#dialog [data-action="close"]').first().click();
 await page.evaluate(()=>window.__promo.freeze());
 await page.locator('#extract-brief-button').click();await page.waitForTimeout(80);
 await page.locator('#dialog').screenshot({path:path.join(root,'assets/exits.png')});
 await page.locator('#dialog [data-action="close"]').first().click();await page.evaluate(()=>window.__promo.freeze());
 await page.evaluate(async()=>{
  const r=window.__promo.raid,{isFree}=await import('./src/math.js');
  const margin=e=>Math.min(e.x,e.y,r.world.bounds.width-e.x,r.world.bounds.height-e.y);
  const boss=r.world.enemies.filter(e=>e.boss).sort((a,b)=>margin(b)-margin(a))[0];
  r.player.value=128;r.player.hp=r.player.maxHp;r.player.energy=100;
  const preferred=Math.atan2(r.world.bounds.height/2-boss.y,r.world.bounds.width/2-boss.x);
  for(let i=0;i<36;i++){const a=preferred+i*Math.PI/18,x=boss.x+Math.cos(a)*350,y=boss.y+Math.sin(a)*350;if(isFree(x,y,30,r.world.obstacles,r.world.bounds)){Object.assign(r.player,{x,y});break;}}
  boss.cooldown=.05;
  for(let i=0;i<35;i++)r.update(1/60,{aimX:boss.x,aimY:boss.y});
  window.__promo.renderer.camera={...r.player};window.__promo.renderer.draw(r,performance.now()/1000,1);window.__promo.ui.update(r,window.__promo.save,true,false);
 });
 await page.waitForTimeout(100);await page.screenshot({path:path.join(root,'assets/boss-fight.png')});
 for(const layout of ['tangram','fracture','blocks','wilds']){
  const data=await page.evaluate(async layout=>{
   const {Raid}=await import('./src/game.js'),{defaultSave}=await import('./src/storage.js'),{Renderer}=await import('./src/renderer.js');
   const canvas=document.createElement('canvas'),map=document.createElement('canvas'),wrap=document.createElement('div');
   wrap.style='position:fixed;width:1000px;height:700px;left:-2000px;top:0';document.body.append(wrap);wrap.append(canvas);map.width=480;map.height=300;
   const renderer=new Renderer(canvas,map),raid=new Raid(defaultSave(),770731,{layout});renderer.bounds=raid.world.bounds;renderer.zones=raid.world.zones;renderer.drawMap(raid);const data=map.toDataURL('image/png');renderer.resizeObserver.disconnect();wrap.remove();return data;
  },layout);
  await fs.writeFile(path.join(root,`assets/map-${layout}.png`),Buffer.from(data.split(',')[1],'base64'));
 }
 if(errors.length)throw Error(errors.join('\n'));
 await fs.writeFile(path.join(root,'source/capture-provenance.json'),JSON.stringify({...provenance,browserErrors:errors},null,2)+'\n');
 await browser.close();console.log('Captured real game screens and four generated map previews.');
})().catch(e=>{console.error(e);process.exit(1);});
